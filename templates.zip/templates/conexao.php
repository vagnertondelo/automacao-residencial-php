<?php
/*$conexao = mysqli_connect("localhost","u602995641_root", "O3OrFbzcE6aw", "u602995641_curso");*/
$conexao = mysqli_connect("localhost", "root", "", "curso_php");

include_once("funcoes.php");