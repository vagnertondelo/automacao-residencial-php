

<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <title>Document</title>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
      <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
      <script type="text/javascript" src="js/js.js"></script>
      <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
      <link rel="stylesheet" type="text/css" href="css/style2.css">
   </head>
   <body>

            <form  action="adicionar_usuario.php" method="post" role="form">
                <h2>CADASTRAR</h2>
                  <div class="form-group">
                    <input type="text" name="nome" id="none" tabindex="1" class="form-control" placeholder="NOME" value="<?php if(isset($nome)){echo $nome;}?>">
                  </div>
                  <div class="form-group">
                    <input type="email" name="email" id="email" tabindex="1" class="form-control" placeholder="EMAIL" value="<?php if(isset($email)){echo $email;}?>">
                  </div>
                  <div class="form-group">
                    <input type="password" name="senha" id="senha" tabindex="2" class="form-control" placeholder="SENHA" value="<?php if(isset($senha)){echo $senha;}?>">
                  </div>
                  <!-- <div class="form-group">
                    <input type="password" name="confirm-password" id="confirm-password" tabindex="2" class="form-control" placeholder="Confirm Password">
                  </div> -->
                  <div class="form-group">
                    <div class="row">
                      <div class="col-sm-6 col-sm-offset-3">
                        <input type="submit" name="register-submit" id="register-submit" tabindex="4" class="form-control btn btn-register" value="CADASTRAR">
                      </div>
                    </div>
                  </div>
              </form>

</body>

