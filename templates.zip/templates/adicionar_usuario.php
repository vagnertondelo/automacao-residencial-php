
<?php
include_once('conexao.php');
include_once('banco.php');
include_once('class/Usuario.php');

$usuario = new Usuario();

$usuario->id   = $_POST['id'];
$usuario->nome =$_POST['nome'];
$usuario->email =$_POST['email'];
$usuario->senha =$_POST['senha'];
$usuario->tipo =$_POST['tipo'];
//echo $id;
if($usuario->id!=""){
 salvarUsuario($conexao,$usuario);
}else{
 insereUsuario($conexao,$usuario);
}

$msg=$id."Salvo com Sucesso";
 header("Location:index.php?msg={$msg}");