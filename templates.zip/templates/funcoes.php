<?php  
function valida_sessao() {
	if (!$_SESSION['logado']) {
		header("Location: valida_login.php?sair=sair");
	}
}
?>