<?php

// Banco Referente a Tarefa


function insereTarefa($conexao,$nome,$descricao,$prazo,$prioridade,$finalizado)
{
	$finalizado =="on"? $finalizado = 1 : $finalizado =0;

$query =  "insert into tarefas(nome,descricao,prazo,prioridade,finalizado) VALUES('{$nome}','{$descricao}',{$prazo},'{$prioridade}','{$finalizado}')";
mysqli_query($conexao,  $query);
}

function deletaTarefa($conexao, $id){
	$query = "delete from tarefas where id = {$id}";
	mysqli_query($conexao,$query);
}
function buscarTarefa($conexao, $id){
	$query = "select * from tarefas where id = {$id}";
	return mysqli_query($conexao,$query);
}

function salvaTarefa($conexao,$id,$nome,$descricao,$prazo,$prioridade,$finalizado){
	
	$finalizado =="on"? $finalizado = 1 : $finalizado =0;
	
	 $query = " update tarefas set nome = '{$nome}',descricao='{$descricao}',prazo = {$prazo}, prioridade = '{$prioridade}', finalizado ='{$finalizado}'
	where id='{$id}'";
	mysqli_query($conexao, $query);
}



// -------------------------------------------------------------------------------------------------------



// Banco referente a Usuario


 
function insereUsuario($conexao, Usuario $usuario){
	
	
	

$query = "INSERT INTO usuarios (nome,email,senha,tipo) values('{$usuario->nome}',
 '{$usuario->email}',{$usuario->senha},'{$usuario->tipo}')";

mysqli_query($conexao, $query);
}

function salvarUsuario($conexao,Usuario $usuario){
	

	
	 $query = "update usuarios set nome='{$usuario->nome}',email='{$usuario->email}',senha='($usuario->senha)',tipo=
	 '($usuario->tipo)' where 'id={$usuario->id}'";
	 mysqli_query($conexao, $query);
	 
}
 
function deletaUsuario($conexao,$id){
	$query="delete from usuarios where id ={$id}";
	mysqli_query($conexao, $query);
	
}
function buscarUsuario($conexao,$id){
	$query="select * from usuarios where id ={$id}";
	return mysqli_query($conexao, $query);
}



// -------------------------------------------------------------------------------------------------------------------
 

 // Banco referente a Produto


function insereProduto($conexao,$nome,$descricao,$valor,$disponivel){
	
	
	

 $query = "INSERT INTO produto (nome,descricao,valor,disponivel) values('{$nome}',
 '{$descricao}',{$valor},'{$disponivel}')";

mysqli_query($conexao, $query);
}

function salvarProduto($conexao,$id,$nome,$descricao,$valor,$disponivel){
	

	
	 $query = "update produto set nome='{$nome}',descricao='{$descricao}',valor='($valor)',disponivel=
	 '($disponivel)' where id={$id}";
	 mysqli_query($conexao, $query);
	 
}
 
function deletaProduto($conexao,$id){
	$query="delete from produto where id ={$id}";
	mysqli_query($conexao, $query);
	
}
function buscarProduto($conexao,$id){
	$query="select * from produto where id ={$id}";
	return mysqli_query($conexao, $query);
}


?>

