
<?php
/*



 ****  TABELA DE REFERENCIAS E PORTAS ****
 msgArduino    ={AA ,AB ,AC ,AD ,AE ,AF ,AG ,AH ,AI ,AJ ,AK  ,AL  ,AM  }
 portasArduino ={A0 ,A1 ,A2 ,A3 ,A4 ,A5 ,4  ,5  ,6  ,7  ,8   ,9   ,10  }
 refPHP        ={0  ,1  ,2  ,3  ,4  ,5  ,6  ,7  ,8  ,9  ,10  ,11  ,12  }

 Ex: para enviar uma mensagem para a Porta digital 7 do arduino.
     enviamos "AJ"...
     e para referenciar a porta 4 dentro do PHP usamos o valor 9.
     e assim funciona para as demais, conforme tabela acima.
     
*/

 	$sock = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
  socket_connect($sock,"10.0.0.120", 8081); // IP do Arduino e porta de comunicação.
 
 // *************       variaveis para manipulação do usuário...      ************************
 // Aqui você define os nomes dos botões e se eles devem (true) ou não (false) aparecer na tela.
 // INICIO
 
  $titulodoAmbiente = "Sistema de Iluminação - Referencia Botao 1";  // Altera o texto dentro das aspas.
  // $nomebotao1 = é o nome que deseja para o botão.
  // $msgArduino = é a mensagem conforme a porta do Arduino que o botão quer ligar, conforme TABELA acima.
  // $refPHP     = verifique na TABELA a porta do Arduino que definiu para o botao e altera o valor conforme TABELA
  // $aparecebotao = coloque (true) para aparecer o botao e (false) para não aparecer
  
  $nomebotao1 = "SALA"; $msgArduino1 ="AA"; $refPHP1  = 0;  $aparecebotao1  = true;  
  $nomebotao2 = "COZINHA"; $msgArduino2 ="AB"; $refPHP2  = 1;  $aparecebotao2  = true;
  $nomebotao3 = "QUARTO"; $msgArduino3 ="AC"; $refPHP3  = 2;  $aparecebotao3  = true;
  $nomebotao4 = "LAVANDERIA"; $msgArduino4 ="AD"; $refPHP4  = 3;  $aparecebotao4  = true;
  $nomebotao5 = "QUARTO 2"; $msgArduino5 ="AE"; $refPHP5  = 4;  $aparecebotao5  = true;
  $nomebotao6 = "TV"; $msgArduino6 ="AF"; $refPHP6  = 5;  $aparecebotao6  = true;
  $nomebotao7 = "RADIO"; $msgArduino7 ="AG"; $refPHP7  = 6;  $aparecebotao7  = true;
  $nomebotao8 = "CAFETEIRA"; $msgArduino8 ="AH"; $refPHP8  = 7;  $aparecebotao8  = true;
  $nomebotao9 = "TV QUARTO"; $msgArduino9 ="AI"; $refPHP9  = 8;  $aparecebotao9  = true;
  $nomebotao10= "AR-CONDICIONADO";$msgArduino10="AJ"; $refPHP10 = 9;  $aparecebotao10 = true; 
  
 

 $referencia = "B#";
 $liga       = "1";
 $desliga    = "0";
 
   
// Seta o Tipo do botão
$type1 = "image";
$type2 = "image";
$type3 = "image";
$type4 = "image";
$type5 = "image";
$type6 = "image";
$type7 = "image";
$type8 = "image";
$type9 = "image";
$type10 = "image";


// condição para aparecer ou não o botão.
  if( $aparecebotao1 == false){$nomebotao1 = ""; $type1 = "hidden";}
  if( $aparecebotao2 == false){$nomebotao2 = ""; $type2 = "hidden";}
  if( $aparecebotao3 == false){$nomebotao3 = ""; $type3 = "hidden";}
  if( $aparecebotao4 == false){$nomebotao4 = ""; $type4 = "hidden";}
  if( $aparecebotao5 == false){$nomebotao5 = ""; $type5 = "hidden";}
  if( $aparecebotao6 == false){$nomebotao6 = ""; $type6 = "hidden";}
  if( $aparecebotao7 == false){$nomebotao7 = ""; $type7 = "hidden";}
  if( $aparecebotao8 == false){$nomebotao8 = ""; $type8 = "hidden";}
  if( $aparecebotao9 == false){$nomebotao9 = ""; $type9 = "hidden";}
  if( $aparecebotao10 == false){$nomebotao10 = ""; $type10 = "hidden";}
 

if(isset($_POST['bits']))
 {
   $msg = $_POST['bits'];

           if(isset($_POST['btn1']) && $aparecebotao1 == true)
           {if($msg[$refPHP1]=='1'){$escreve = $desliga.$msgArduino1; } else {$escreve = $liga.$msgArduino1;}}
            
           if(isset($_POST['btn2']) && $aparecebotao2 == true)
           {if($msg[$refPHP2]=='1'){$escreve = $desliga.$msgArduino2; } else {$escreve = $liga.$msgArduino2;}}
           
           if(isset($_POST['btn3']) && $aparecebotao3 == true)
           {if($msg[$refPHP3]=='1'){$escreve = $desliga.$msgArduino3; } else {$escreve = $liga.$msgArduino3;}}
           
           if(isset($_POST['btn4']) && $aparecebotao4 == true)
           {if($msg[$refPHP4]=='1'){$escreve = $desliga.$msgArduino4; } else {$escreve = $liga.$msgArduino4;}}       
           
           if(isset($_POST['btn5']) && $aparecebotao5 == true)
           {if($msg[$refPHP5]=='1'){$escreve = $desliga.$msgArduino5; } else {$escreve = $liga.$msgArduino5;}}
           
           if(isset($_POST['btn6']) && $aparecebotao6 == true)
           {if($msg[$refPHP6]=='1'){$escreve = $desliga.$msgArduino6; } else {$escreve = $liga.$msgArduino6;}}
           
           if(isset($_POST['btn7']) && $aparecebotao7 == true)
           {if($msg[$refPHP7]=='1'){$escreve = $desliga.$msgArduino7; } else {$escreve = $liga.$msgArduino7;}}
           
           if(isset($_POST['btn8']) && $aparecebotao8 == true)
           {if($msg[$refPHP8]=='1'){$escreve = $desliga.$msgArduino8; } else {$escreve = $liga.$msgArduino8;}}
           
           if(isset($_POST['btn9']) && $aparecebotao9 == true)
           {if($msg[$refPHP9]=='1'){$escreve = $desliga.$msgArduino9; } else {$escreve = $liga.$msgArduino9;}}
           
           if(isset($_POST['btn10']) && $aparecebotao10 == true)
           {if($msg[$refPHP10]=='1'){$escreve = $desliga.$msgArduino10; } else {$escreve = $liga.$msgArduino10;}}
           
            
            
            
            
     $envia = $escreve.$referencia;
     socket_write($sock,$envia,strlen($envia));
 }

  

socket_write($sock,'AA#',3);
$status = socket_read($sock,16);

  if ($status[$refPHP1]=='0')
         $btn1 = "imagens/btn_lamp_off.png";else $btn1 = "imagens/btn_lamp_on.png";
  if ($status[$refPHP2]=='0')
         $btn2 = "imagens/btn_lamp_off.png";else $btn2 = "imagens/btn_lamp_on.png";
  if ($status[$refPHP3]=='0')
         $btn3 = "imagens/btn_lamp_off.png";else $btn3 = "imagens/btn_lamp_on.png";
  if ($status[$refPHP4]=='0')
         $btn4 = "imagens/btn_lamp_off.png";else $btn4 = "imagens/btn_lamp_on.png";
  if ($status[$refPHP5]=='0')
         $btn5 = "imagens/btn_lamp_off.png";else $btn5 = "imagens/btn_lamp_on.png";
  if ($status[$refPHP6]=='0')
         $btn6 = "imagens/btn_lamp_off.png";else $btn6 = "imagens/btn_lamp_on.png";
  if ($status[$refPHP7]=='0')
         $btn7 = "imagens/btn_lamp_off.png";else $btn7 = "imagens/btn_lamp_on.png";
  if ($status[$refPHP8]=='0')
         $btn8 = "imagens/btn_lamp_off.png";else $btn8 = "imagens/btn_lamp_on.png";
  if ($status[$refPHP9]=='0')
         $btn9 = "imagens/btn_lamp_off.png";else $btn9 = "imagens/btn_lamp_on.png";
  if ($status[$refPHP10]=='0')
         $btn10 = "imagens/btn_lamp_off.png";else $btn10 = "imagens/btn_lamp_on.png";

$msg = $status;
socket_close($sock);

     
?>