

<?php

//require_once("class/Usuario.php");
//$usuario = new Usuario();


//$usuario->nome="Vagner";

//var_dump($usuario);




session_start();

include_once ("funcoes.php");
valida_sessao();

$titulo_pagina = "Usuários";
$rodape_pagina = "Este é um rodapé";
include ('cabecalho.php');
include ('conexao.php');
include_once('conexao.php');
$query     = "select * from usuarios";
$resultado = mysqli_query($conexao, $query);
?>
<?php include ('barra-nav.php');?>
<div class="container-fluid">
	<div class="col-sm-12">
		<a href="usuario.php" class="btn btn-md btn-success">Adicionar novo</a>
<?php
if (isset($_GET['msg'])) {
	echo "<div class='alert alert-success'>".$_GET['msg']."</div>";
}?>

<div class="col-sm-6">
	<div class="well well-sm">
		<table class="table">
			<thead>
			
				<td>Nome</td>
				<td>Senha</td>
				<td>Email</td>
				<td>Tipo</td>
				<td>Opção</td>
			</thead>
			<?php
foreach ($resultado as $usuarios=> $usuario) {
echo "<td>".$usuario['nome']."</td>";
echo "<td>".substr($usuario['senha'],0,30)."</td>";
echo "<td>".$usuario['email']."</td>";
echo "<td>".$usuario['tipo']."</td>";
echo "<td>";

			?>


			<form action="editar_usuarios.php" method="post">
				<input type="hidden" name="id" value="<?=$usuario['id'] ?>"/>
				<button class="btn btn-xs btn-info">
					<span class='glyphicon glyphicon-edit'></span>
				</button>
			</form>
			<form action="excluir_usuarios.php" method="post">
				<input type="hidden" name="id" value="<?=$usuario['id'] ?>"/>
				<button class="btn btn-xs btn-danger">
					<span class='glyphicon glyphicon-trash'></span>
				</button>
			</form>
			<?php
			echo "</td>";
			echo "</tr>";
			}
			?>
		</table>
	</div>
</div>

