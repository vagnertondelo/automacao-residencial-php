
<<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Document</title>


  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <script type="text/javascript" src="js/js.js"></script>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/style2.css">
</head>
<body>
<div class="container">
   <div class="row">
    <div class="col-md-6 col-md-offset-3">
      <div class="panel panel-login">
        <div class="panel-body">
          <div class="row">
            <div class="col-lg-12">
            <?php
      if(isset($_GET['msg'])){
        echo"<div class='alert alert-success'>".$_GET['msg']."</div>";
      }
      ?>
              <form id="login-form" action="valida_login.php" method="POST"  name= "formulario" role="form" style="display: block;">
                <h2>LOGIN</h2>
                  <div class="form-group">
                    <input type="text" name="email" id="username" tabindex="1" class="form-control" placeholder="EMAIL" value="">
                  </div>
                  <div class="form-group">
                    <input type="password" name="senha" id="password" tabindex="2" class="form-control" placeholder="SENHA">
                  </div>
                  <!-- <div class="col-xs-6 form-group pull-left checkbox">
                    <input id="checkbox1" type="checkbox" name="remember">
                    <label for="checkbox1">Remember Me</label>   
                  </div> -->
                  <div class="col-xs-6 form-group pull-right">     
                        <input type="submit" name="login-submit" id="login-submit" tabindex="4" class="form-control btn btn-login" onclick="senhanula()" value="ENTRAR">
                  </div>
              </form>
              <form id="register-form" action="adicionar_usuario.php" method="post" role="form" style="display: none;">
                <h2>CADASTRAR</h2>
                  <div class="form-group">
                    <input type="text" name="nome" id="none" tabindex="1" class="form-control" placeholder="NOME" value="<?php if(isset($nome)){echo $nome;}?>">
                  </div>
                  <div class="form-group">
                    <input type="email" name="email" id="email" tabindex="1" class="form-control" placeholder="EMAIL" value="<?php if(isset($email)){echo $email;}?>">
                  </div>
                  <div class="form-group">
                    <input type="password" name="senha" id="senha" tabindex="2" class="form-control" placeholder="SENHA" value="<?php if(isset($senha)){echo $senha;}?>">
                  </div>
                  <!-- <div class="form-group">
                    <input type="password" name="confirm-password" id="confirm-password" tabindex="2" class="form-control" placeholder="Confirm Password">
                  </div> -->
                  <div class="form-group">
                    <div class="row">
                      <div class="col-sm-6 col-sm-offset-3">
                        <input type="submit" name="register-submit" id="register-submit" tabindex="4" class="form-control btn btn-register" value="CADASTRAR">
                      </div>
                    </div>
                  </div>
              </form>
            </div>
          </div>
        </div>
        <div class="panel-heading">
          <div class="row">
            <div class="col-xs-6 tabs">
              <a href="#" class="active" id="login-form-link"><div class="login">LOGIN</div></a>
            </div>
            <div class="col-xs-6 tabs">
              <a href="#" id="register-form-link"><div class="register">CADASTRAR</div></a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

</body>
</html>