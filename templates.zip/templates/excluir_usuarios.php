<?php
include('conexao.php');
include('banco.php');

$id   = $_POST['id'];

deletaUsuario($conexao, $id);
$msg=$id."Excluido com Sucesso";

header("location:usuarios.php?msg={$msg}");
