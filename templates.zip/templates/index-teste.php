<html>
<head>
  
  <title>Document</title>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
      <!-- <script src="https://fb.me/react-0.13.3.min.js"></script>
      <script src="https://fb.me/JSXTransformer-0.13.3.js"></script> -->
      <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
      <script type="text/javascript" src="js/js.js"></script>
      <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
      <link rel="stylesheet" type="text/css" href="css/style2.css">

</head>
<body>
 
<?php
$sock = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
// Se conecta ao IP e Porta:
socket_connect($sock,"10.0.0.120", 8081);
 
// Executa a ação correspondente ao botão apertado.
if(isset($_POST['bits'])) {
  $msg = $_POST['bits'];
  if(isset($_POST['Fora'   ])){ if($msg[0]=='1') { $msg[0]='0'; } else { $msg[0]='1'; }}
  if(isset($_POST['Quarto1'])){ if($msg[1]=='1') { $msg[1]='0'; } else { $msg[1]='1'; }}
  if(isset($_POST['Quarto2'])){ if($msg[2]=='1') { $msg[2]='0'; } else { $msg[2]='1'; }}
  if(isset($_POST['Sala'   ])){ if($msg[3]=='1') { $msg[3]='0'; } else { $msg[3]='1'; }}
  if(isset($_POST['Pequeno'])){ $msg = 'P#'; }
  if(isset($_POST['Grande' ])){ $msg = 'G#'; }
  socket_write($sock,$msg,strlen($msg));
}
  
// Espera e lê o status e define a cor dos botões de acordo.
$status = socket_read($sock,6);

   
  echo "<form method =\"post\" action=\"teste.php\">";
  echo "<input type=\"hidden\" name=\"bits\" value=\"$status\">";
  echo "<button style=\"width:70; ;font: bold 14px Arial\" type = \"Submit\" Name = \"Fora\">Fora</button></br></br>";
  echo "<button style=\"width:70;  ;font: bold 14px Arial\" type = \"Submit\" Name = \"Quarto1\">Quarto1</button></br></br>";
  echo "<button style=\"width:70;  ;font: bold 14px Arial\" type = \"Submit\" Name = \"Quarto2\">Quarto2</button></br></br>";
  echo "<button style=\"width:70;  ;font: bold 14px Arial\" type = \"Submit\" Name = \"Sala\">Sala</button></br></br></br>";
  echo "<button style=\"width:90;font: bold 14px Arial\" type = \"Submit\" Name = \"Pequeno\">Portao Pequeno</button></br></br>";
  echo "<button style=\"width:90;font: bold 14px Arial\" type = \"Submit\" Name = \"Grande\">Portao Grande</button></br></br>";
  echo "</form>";

// Caso ele não receba o status corretamente, avisa erro.

socket_close($sock);
?>
 
</body>
</html>

     