<?php

include_once ("conexao.php");

if ($_GET['sair'] == "sair") {
	session_start();
	session_destroy();
	header("Location: index.php");
} else {
	$email = trim($_POST['email']);
	$senha = trim($_POST['senha']);

	$query = "select * from usuarios where email ='{$email}' and senha ='{$senha}'";

	$resultado = mysqli_query($conexao, $query);
	$usuario   = mysqli_fetch_row($resultado);
	if ($usuario != null) {
		session_start();
		$_SESSION['id']     = $usuario[0];
		$_SESSION['nome']   = $usuario[1];
		$_SESSION['email']  = $usuario[2];
		$_SESSION['tipo']   = $usuario[4];
		$_SESSION['logado'] = TRUE;
		header("Location: dashboard.php");
	} else {
		header("Location: index.php");
	}
}
/*























<?php

include_once ("conexao.php");
if (isset($_GET['sair']) == "sair") {
session_destroy();
header("Location: index.php");
} else {

$email = trim($_POST['email']);
$senha = trim($_POST['senha']);

$query = "select * from usuarios where email ='{$email}' and senha ='{$senha}'";

$resultado = mysqli_query($conexao, $query);
$usuario   = mysqli_fetch_row($resultado);
if ($usuario != null) {
session_start();
$_SESSION['id']    = $usuario[0];
$_SESSION['nome']  = $usuario[1];
$_SESSION['email'] = $usuario[2];
$_SESSION['tipo']  = $usuario[4];
header("Location: dashboard.php");
} else {
header("Location: index.php");
}
}*/