<?php
session_start();

include_once ("funcoes.php");
include_once ("server-arduino.php");
valida_sessao();
?>


<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <title>Document</title>
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
      <!-- <script src="https://fb.me/react-0.13.3.min.js"></script>
	    <script src="https://fb.me/JSXTransformer-0.13.3.js"></script> -->
      <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
      <script type="text/javascript" src="js/js.js"></script>
      <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
      <link rel="stylesheet" type="text/css" href="css/style2.css">
   </head>
   <body>

      <nav class="navbar navbar-inverse navbar-fixed-top menu-bar">
         <div class="container">
            <div class="navbar-header">
               <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
               <span class="sr-only">Toggle navigation</span>
               <span class="icon-bar"></span>
               <span class="icon-bar"></span>
               <span class="icon-bar"></span>
               </button>
            </div>
            <div id="navbar" class="collapse navbar-collapse">
               <ul class="nav navbar-nav">
                <li class="menu"><a href="dashboard.php"  id="">Todos Acionamentos</a></li>
                  <li class="menu"><a href="#" class="active" id="register-form-link">Comôdos</a></li>
                  <li class="menu"><a href="eletromesticos.php" id="componente">Eletrodómesticos</a></li>
                  <!-- <li class="menu"><a href="dashboard.php"  id="login-form-link">Sensores</a></li> -->
                  <li class="menu"><a href="#" id="camera">Câmeras</a></li>
               </ul>
               <ul class="nav navbar-nav navbar-right">
                  <li class="dropdown">
                     <a href="#" class="dropdown-toggle" data-toggle = "dropdown" role="button" 
                        aria-haspopup="true" aria-expanded="false"><?=$_SESSION['nome'];?><span class="caret"></span></a>
                     <ul class="dropdown-menu">
                        <!-- <li><a href="perfil.php"></a></li> -->
                        <li role="separator" class="divider"></li>
                        <li><a href="valida_login.php?sair=sair">SAIR</a></li>
                     </ul>
                  </li>
               </ul>
            </div>
            <!--/.nav-collapse -->
         </div>
      </nav>
      <div class="container">
         <div class="row">
            <div class="col-md-12">
               <div class="panel panel-login">
                  <div class="panel-body">
                     <div class="row">
                        <div class="col-lg-12">
                           <form id="login-form" action="" method="post" role="form" style="display: none;">
                              <h1 class="col-sm-12 text-center">Sensores</h1>
                              <div class="panel-heading">
                                 <div class="row">
                                    <div class="col-sm-12"></div>
                                 </div>
                                 <hr class="barra"/>
                              </div>
                           </form>
                           <!-- Botoes de controle-->			
                           <form name="form6" method="post" action="dashboard.php" id="register-form" method="post" role=	"form" style="display: block;">
                              <h1 class="col-sm-12 text-center">Comôdos</h1>
                              <div class="panel-heading">
                                 <div class="panel-heading">
                                    <div class="row">
                                       <div class="col-sm-12"></div>
                                    </div>
                                    <hr class="barra"/>
                                 </div>
                                 <input type="hidden" name="envia" value="<?php echo $envia ?>"></input>
                                 <input type="hidden" name="bits" value="<?php echo $msg ?>"></input>
                                 <div class="row">
                                    <div class="col-sm-4">
                                       <div class="item-botao">
                                          <!-- Configuração do botão 1 -->
                                          <button  type = "submit" Name = "btn1">
                                          <input name="btn1" type="<?php echo $type1 ?>" id="btn1" src="<?php echo $btn1; ?>" value="0"></input>
                                          </button>
                                          <p class="nome-botao"><?php echo $nomebotao1?></p>
                                       </div>
                                    </div>
                                    <div class="col-sm-4">
                                       <div class="item-botao">
                                          <!-- Configuração do botão 2 -->

                                          <div id="btn2" class="lampada <? echo $btn2;?>">
											<p class="nome-botao"><?php echo $nomebotao2?></p>
                                          </div>

                                          <button  type = "submit" Name = "btn2" >
                                          <input name="btn2" type="<?php echo $type2 ?>" id="btn2" src="<?php echo $btn2; ?>" value="0">	</input>
                                          </button>
                                          <p class="nome-botao"><?php echo $nomebotao2?></p>
                                       </div>
                                    </div>
                                    <div class="col-sm-4">
                                       <div class="item-botao">
                                          <!-- Configuração do botão 3 -->
                                          <button  type = "submit" Name = "btn3" >
                                          <input name="btn3" type="<?php echo $type3 ?>" id="btn3" src="<?php echo $btn3; ?>" value="0"></input>
                                          </button>
                                          <p class="nome-botao"><?php echo $nomebotao3?></p>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-sm-4">
                                       <div class="item-botao">
                                          <!-- Configuração do botão 4 -->
                                          <button  type = "submit" Name = "btn4">
                                          <input name="btn4" type="<?php echo $type4 ?>" id="btn4" src="<?php echo $btn4; ?>" value="0"></input>
                                          </button>
                                          <p class="nome-botao"><?php echo $nomebotao4?></p>
                                       </div>
                                    </div>
                                    <div class="col-sm-4">
                                       <div class="item-botao">
                                          <!-- Configuração do botão 5 -->
                                          <button  type = "submit" Name = "btn5" >
                                          <input name="btn5" type="<?php echo $type5 ?>" id="btn5" src="<?php echo $btn5; ?>" 
                                             value="0"></input>
                                          </button>
                                          <p class="nome-botao"><?php echo $nomebotao5?></p>
                                       </div>
                                    </div>
                                 </div>
                              </div>

                           </form>
                           <!-- Cameras -->
                           <form id="camera-form" action="" method="post" role="form" style="display: none;">
                              <h1 class="col-sm-12 text-center">Câmeras</h1>
                              <div class="panel-heading">
                                 <div class="row">
                                    <div class="col-sm-12">	</div>
                                 </div>
                                 <hr class="barra">
                                 <div class="row">

								<div class="col-sm-6" id="teste">
								<img src="http://10.0.0.100:8081/video" alt="http://10.0.0.100:8081/video" width="100%" height="300px">
                        
								</div>
		

                                    <!-- <video autoplay loop muted class="col-sm-6" >
                                       <source src="videos/video.mp4" type="video/mp4">
                                    </video> -->
                                    <video autoplay loop muted class="col-sm-6">
                                       <source src="videos/video.mp4" type="video/mp4">
                                    </video>
                                 </div>
                              </div>
                           </form>
                           <!-- Eletrodomesticos -->
                           <form name="form6" method="post" action="dashboard.php" id="componete-form" method="post" role="form" style="display: block;">
                              <h1 class="col-sm-12 text-center">Eletrodómesticos</h1>
                              <div class="panel-heading">
                                 <div class="row">
                                    <div class="col-sm-12"></div>
                                 </div>
                                 <hr class="barra"/>
                              </div>
                              <input type="hidden" name="envia" value="<?php echo $envia ?>"></input>
                              <input type="hidden" name="bits" value="<?php echo $msg ?>"></input>
                              <div>
                                 <div class="row">
                                    <div class="col-sm-4">
                                       <div class="item-botao">
                                          <!-- Configuração do botão 6 -->
                                          <button  type = "submit" Name = "btn6">
                                          <input name="btn6" type="<?php echo $type6 ?>" id="btn6" src="<?php echo $btn6; ?>" value="0"></input>
                                          </button>
                                          <p class="nome-botao"><?php echo $nomebotao6?></p>
                                       </div>
                                    </div>
                                    <div class="col-sm-4">
                                       <div class="item-botao">
                                          <!-- Configuração do botão 7 -->
                                          <button  type = "submit" Name = "btn7" >
                                          <input name="btn7" type="<?php echo $type7 ?>" id="btn7" src="<?php echo $btn7; ?>" value="0"></input>
                                          </button>
                                          <p class="nome-botao"><?php echo $nomebotao7?></p>
                                       </div>
                                    </div>
                                    <div class="col-sm-4">
                                       <div class="item-botao">
                                          <!-- Configuração do botão 8 -->
                                          <button  type = "submit" Name = "btn8" >
                                          <input name="btn8" type="<?php echo $type8 ?>" id="btn8" src="<?php echo $btn8; ?>" value="0"></input>
                                          </button>
                                          <p class="nome-botao"><?php echo $nomebotao8?></p>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="row">
                                    <div class="col-sm-4">
                                       <div class="item-botao">
                                          <!-- Configuração do botão 9 -->
                                          <button  type = "submit" Name = "btn9">
                                          <input name="btn9" type="<?php echo $type9 ?>" id="btn9" src="<?php echo $btn9; ?>" value="0"></input>
                                          </button>
                                          <p class="nome-botao"><?php echo $nomebotao9?></p>
                                       </div>
                                    </div>
                                    <div class="col-sm-4">
                                       <div class="item-botao">
                                          <!-- Configuração do botão 10 -->
                                          <button  type = "submit" Name = "btn10" >
                                          <input name="btn10" type="<?php echo $type10 ?>" id="btn10" src="<?php echo $btn10; ?>" value="0"></input>
                                          </button>
                                          <p class="nome-botao"><?php echo $nomebotao10?></p>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </form>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </body>
</html>